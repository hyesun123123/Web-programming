package service.study;

import java.util.List;

import dto.Study;

public interface StudyCateService {
	
	public List<Study> getCateStudyList(int st_code);


}
