package dto;

public class Teammate {

	private int u_no;
	private String u_name;
	private int study_no;
	private String study_name;
	private int ts_statecode;
	private String ts_statename;
	private String ss_yesno;
	public int getU_no() {
		return u_no;
	}
	public void setU_no(int u_no) {
		this.u_no = u_no;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public int getStudy_no() {
		return study_no;
	}
	public void setStudy_no(int study_no) {
		this.study_no = study_no;
	}
	public String getStudy_name() {
		return study_name;
	}
	public void setStudy_name(String study_name) {
		this.study_name = study_name;
	}
	public int getTs_statecode() {
		return ts_statecode;
	}
	public void setTs_statecode(int ts_statecode) {
		this.ts_statecode = ts_statecode;
	}
	public String getTs_statename() {
		return ts_statename;
	}
	public void setTs_statename(String ts_statename) {
		this.ts_statename = ts_statename;
	}
	public String getSs_yesno() {
		return ss_yesno;
	}
	public void setSs_yesno(String ss_yesno) {
		this.ss_yesno = ss_yesno;
	}
	
	
	
	
}
